package tw.platform.sideProject.model;

public class mimiMessage {

}
